import pandas as pd

from strategy import add_signals, position_quantity


def test_position_quantity_respects_allocation_cap():
    cfg = {"risk_per_trade_pct": 1, "max_position_pct": 10}
    assert position_quantity(10_000, 100, 99, cfg) == 10


def test_bullish_sweep_requires_reclaim_and_volume():
    idx = pd.date_range("2026-01-01", periods=8, freq="15min")
    df = pd.DataFrame({
        "open": [10] * 7 + [9.8], "high": [10.2] * 7 + [10.3],
        "low": [9.5] * 7 + [9.3], "close": [10] * 7 + [10.1],
        "volume": [100] * 7 + [300],
    }, index=idx)
    cfg = {"sweep_lookback": 3, "volume_lookback": 3, "ema_period": 3,
           "volume_multiplier": 1.5, "require_trend": False}
    result = add_signals(df, cfg)
    assert bool(result.iloc[-1].long_signal)

